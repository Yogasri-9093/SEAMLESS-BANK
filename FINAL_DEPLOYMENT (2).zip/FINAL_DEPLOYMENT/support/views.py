# views.py
'''from django.views.generic import CreateView, ListView
from django.urls import reverse_lazy
from .models import SupportTicket
from .forms import SupportTicketForm

class SubmitTicketView(CreateView):
    model = SupportTicket
    form_class = SupportTicketForm
    template_name = 'support/submit_ticket.html'
    success_url = reverse_lazy('support:ticket_list')

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)

class TicketListView(ListView):
    model = SupportTicket
    template_name = 'support/ticket_list.html'

    def get_queryset(self):
        return SupportTicket.objects.filter(user=self.request.user)
# views.py
from django.views.generic import DetailView

class TicketDetailView(DetailView):
    model = SupportTicket
    template_name = 'support/ticket_detail.html'

# In urls.py
'''
# support/views.py
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import CreateView, ListView, DetailView
from django.urls import reverse_lazy
from .models import SupportTicket
from .forms import SupportTicketForm

class SubmitTicketView(LoginRequiredMixin, CreateView):
    model = SupportTicket
    form_class = SupportTicketForm
    template_name = 'support/submit_ticket.html'
    success_url = reverse_lazy('support:ticket_list')

    def form_valid(self, form):
        form.instance.user = self.request.user  # Associate ticket with the logged-in user
        return super().form_valid(form)

class TicketListView(LoginRequiredMixin, ListView):
    model = SupportTicket
    template_name = 'support/ticket_list.html'

    def get_queryset(self):
        return SupportTicket.objects.filter(user=self.request.user)  # Show only user's tickets

class TicketDetailView(LoginRequiredMixin, DetailView):
    model = SupportTicket
    template_name = 'support/ticket_detail.html'
# views.py
from django.views.generic import DetailView
from .models import SupportTicket

class SupportTicketDetailView(DetailView):
    model = SupportTicket
    template_name = 'support/ticket_detail.html'
    context_object_name = 'ticket'

# views.py
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from .models import SupportTicket
from .forms import SupportTicketForm  # Import your existing form
from django.contrib import messages

@login_required
def ticket_detail(request, ticket_id):
    ticket = get_object_or_404(SupportTicket, id=ticket_id)

    if request.method == "POST":
        # Update the ticket with the admin's solution
        solution = request.POST.get('solution')
        ticket.solution = solution
        ticket.status = 'closed'
        ticket.save()
        messages.success(request, "Ticket has been successfully closed with a solution.")
        return redirect('support:ticket_list')

    return render(request, 'support/ticket_detail.html', {'ticket': ticket})
# views.py (admin)
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import SupportTicket
from .forms import AdminResponseForm

def admin_response_view(request, ticket_id):
    ticket = get_object_or_404(SupportTicket, id=ticket_id)
    if request.method == 'POST':
        form = AdminResponseForm(request.POST, instance=ticket)
        if form.is_valid():
            form.save()
            messages.success(request, 'Response submitted successfully.')
            return redirect('admin:app_supportticket_changelist')
    else:
        form = AdminResponseForm(instance=ticket)

    return render(request, 'supportticket_response.html', {'form': form, 'ticket': ticket})
